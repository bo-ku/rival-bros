/**
 * Name : Bo Ku
 * PennKey : boku
 * Recitation : 220
 * 
 * Execution: java ClickArt
 *
 * A program that responds to user's clicks on a canvas
 * Description: When a key is pressed, a background of a blue sky with clouds over a field of grass is drawn. When pressed again, an iteration of the background is drawn. When user presses an area on the screen, an image of a dog is drawn. This is scaled based on the distance from the horizon.
 */
public class ClickArt {
  public static void main(String[] args) {
    /* Is this the first time we are drawing the background?
     * Make sure you utilize this variable somewhere within the 
     * while loop below
     */
    boolean firstTime = true;
    
    while (true) {
      // if a key is pressed, redraw background
      
      if (PennDraw.hasNextKeyTyped()) {
        //background of blue sky with clouds and green grass
        char key = PennDraw.nextKeyTyped();
        PennDraw.clear(PennDraw.CYAN);
        PennDraw.setPenColor(0, 170, 0);
        PennDraw.filledRectangle(0.5, 0.25, 0.5, 0.25);
        // loop of random clouds
        int numOfCloud = (int)(Math.random() * 20);
        for (int i = 0; i < numOfCloud; i = i + 1) {
          PennDraw.picture(Math.random(), 1 - Math.random()/2.5, "cloud.png");
        }
firstTime = false;
}

            //if the mouse is clicked...
            if (PennDraw.mousePressed()) {
              //get and store the coordinates of the mouse cursor
              double x = PennDraw.mouseX();
              double y = PennDraw.mouseY();
              //dogs on grass
              if (y <= 0.5) {
                PennDraw.picture(x, y, "dog.png", 15/y, 15/y);
              }
                //planes in sky
                else if ( y > 0.52) {
                  PennDraw.picture(x, y, "plane.png", 70*y, 70*y);
              // draw a scaled shape using the mouse coordinates
            }
            }
    }
  }
}






